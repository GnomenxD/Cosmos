﻿namespace $rootnamespace$
{
	internal class $safeitemname$
	{

	}
}