﻿using CosmosEngine;
using System.Collections.Generic;

namespace $rootnamespace$
{
	public class $safeitemname$ : GameBehaviour
	{
		// Start is called before the first frame update
		protected override void Start()
		{

		}

		// Update is called once per frame
		protected override void Update()
		{

		}
	}
}